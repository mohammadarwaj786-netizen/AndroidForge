# Masjid Account Manager — Android source starter

## Included
- Android Studio project (Kotlin WebView wrapper)
- Hindi, Urdu, and English language toggle, income/expense records, donations, running balance, transaction history
- Monthly totals and print/PDF report via Android print dialog/browser support
- Offline records stored on this device in browser local storage
- JSON export/import backup

## Build APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Let Gradle sync. If Android Studio requests a Gradle wrapper, choose its recommended compatible version.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Debug APK will usually appear under `app/build/outputs/apk/debug/`.

## Important limitations / production checklist
- This starter project has not been compiled or tested on a device in this environment.
- Cloud backup is NOT active yet. JSON backup is manual and local/offline. For secure online backup, configure a Firebase project, Firebase Authentication, Firestore rules, and sync/retry logic before storing real donor/account data online. Do not ship open database rules.
- Browser print/PDF support depends on the Android WebView/device.
- This app is a starting point, not audited accounting software. Export backups regularly and verify records.
- The sample contains no real financial data.


**Android app display name:** قادری تیگی مسجد

The launcher label has been set to the requested Urdu/Arabic-script name. An APK could not be compiled in this environment because Android SDK/Gradle build tools are not installed and external downloads are unavailable. Open this project in Android Studio, install Android SDK 35 if prompted, then use **Build → Build APK(s)**. The generated APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.
